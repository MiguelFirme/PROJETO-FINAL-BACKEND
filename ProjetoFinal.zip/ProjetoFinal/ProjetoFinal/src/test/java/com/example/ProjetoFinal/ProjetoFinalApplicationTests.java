package com.example.ProjetoFinal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoFinalApplicationTests {

	@Test
	void contextLoads() {
	}

}
