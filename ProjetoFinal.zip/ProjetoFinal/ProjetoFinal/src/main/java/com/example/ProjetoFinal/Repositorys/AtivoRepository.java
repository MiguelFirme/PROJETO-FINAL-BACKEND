package com.example.ProjetoFinal.Repositorys;

import com.example.ProjetoFinal.Entidades.Ativo;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AtivoRepository extends JpaRepository<Ativo, Long> {
}
